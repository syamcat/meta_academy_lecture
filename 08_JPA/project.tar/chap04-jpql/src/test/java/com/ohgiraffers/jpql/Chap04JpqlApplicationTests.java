package com.ohgiraffers.jpql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Chap04JpqlApplicationTests {

    @Test
    void contextLoads() {
    }

}
