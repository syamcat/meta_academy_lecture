package com.ohgiraffers.jpql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chap04JpqlApplication {

    public static void main(String[] args) {
        SpringApplication.run(Chap04JpqlApplication.class, args);
    }

}
